<?php
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
/**
 * Admin View: List Code Snippets
 *
 * @package Wealcoder\AnimationAddons\CodeSnippet
 * @since 1.0.0
*/

use Wealcoder\AnimationAddons\CodeSnippet\Helpers;

defined( 'ABSPATH' ) || exit;

// These view files are included in global scope, so a variable named after a
// WordPress global would overwrite it. Hence the wcf_ prefixes below.

$list_table = Helpers::get_list_table( 'wcf-code-snippet' );  // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Backward compatibility with existing wcf hooks.
$wcf_action     = $list_table->current_action();
if ( $wcf_action ) {
	$list_table->process_bulk_action( $wcf_action );
}
$list_table->prepare_items();

// Handle messages.
$message = '';  // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Backward compatibility with existing wcf hooks.
if ( isset( $_GET['message'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$message_code = sanitize_key( wp_unslash( $_GET['message'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$messages     = array(
		'deleted'     => __( 'Snippet(s) deleted successfully.', 'animation-addons-for-elementor' ),
		'activated'   => __( 'Snippet(s) activated successfully.', 'animation-addons-for-elementor' ),
		'deactivated' => __( 'Snippet(s) deactivated successfully.', 'animation-addons-for-elementor' ),
		'error'       => __( 'An error occurred. Please try again.', 'animation-addons-for-elementor' ),
	);

	if ( isset( $messages[ $message_code ] ) ) {
		$message      = $messages[ $message_code ];     // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Backward compatibility with existing wcf hooks.
		$message_type = 'error' === $message_code ? 'error' : 'success';  // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Backward compatibility with existing wcf hooks.
	}
}
?>

<div class="wrap wcf-code-snippet-admin">
	<div class="wcf-admin-page-header">
		<div class="wcf-header-content">
			<h1 class="wp-heading-inline">
				<?php esc_html_e( 'Code Snippets', 'animation-addons-for-elementor' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . \Wealcoder\AnimationAddons\CodeSnippet\CodeSnippet::PAGE_SLUG . '&new=1' ) ); ?>" class="page-title-action">
					<?php esc_html_e( 'Add New Snippet', 'animation-addons-for-elementor' ); ?>
				</a>
			</h1>

			<?php if ( ! empty( $message ) ) : ?>
				<div class="notice notice-<?php echo esc_attr( $message_type ?? 'success' ); ?> is-dismissible">
					<p><?php echo esc_html( $message ); ?></p>
				</div>
			<?php endif; ?>
		</div>
	</div>

	<div class="wcf-admin-page-content">
		<?php
		// Display any additional admin notices.
		if ( method_exists( $list_table, 'admin_notices' ) ) {
			$list_table->admin_notices();
		}
		?>

		<form id="code-snippet-list-table-form" method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" onsubmit="return false;">
			<?php
			$list_table->views();
			$list_table->search_box( __( 'Search Snippets', 'animation-addons-for-elementor' ), 'snippet' );
			$list_table->display();
			?>
		</form>
	</div>
</div>