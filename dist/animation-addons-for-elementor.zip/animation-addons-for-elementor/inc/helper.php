<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly


if ( ! function_exists( 'aaeaddon_get_saved_template_list' ) ) :
	/**
	 * Every Elementor library template, as id => title, for a widget's
	 * template picker.
	 *
	 * Renamed from its `wcf_addons_` spelling in 4.2.0. The old name is a
	 * temporary shim right below (the released add-on calls it on seven lines);
	 * see that shim's docblock for when it goes.
	 *
	 * @since 4.2.0
	 *
	 * @param array|null $args Optional `get_posts()` overrides.
	 * @return array<int,string>
	 */
	function aaeaddon_get_saved_template_list( $args = null ) {

		static $cache = null;

		if ( $cache !== null ) {
			return $cache;
		}

		$post_list = array();

		if ( ! current_user_can( 'edit_posts' ) ) {
			return $post_list;
		}

		$defaults = array(
			'post_type'      => 'elementor_library',
			'post_status'    => 'publish',
			'posts_per_page' => 50, // ⚠️ avoid -1 for performance
			'orderby'        => 'title',
			'order'          => 'ASC',
			'no_found_rows'  => true, // 🚀 performance boost
		);

		$parsed_args = wp_parse_args( $args, $defaults );

		$parsed_args['post_type'] = 'elementor_library';

		$posts = get_posts( $parsed_args );

		if ( ! empty( $posts ) ) {
			foreach ( $posts as $post ) {
				// ⚠️ No escaping here → escape on output
				$post_list[ $post->ID ] = $post->post_title;
			}
		}

		$cache = $post_list;

		return $post_list;
	}
endif;

if ( ! function_exists( 'wcf_addons_get_saved_template_list' ) ) :
	/**
	 * Pre-4.2 name of aaeaddon_get_saved_template_list() -- COMPATIBILITY SHIM.
	 *
	 * The RELEASED paid add-on (Pro <= 4.2.x) calls this name on seven lines
	 * with no function_exists() guard, and free 4.2.1 reached WordPress.org on
	 * 2026-09-17 without it -- so every Pro site that auto-updated free before
	 * updating Pro hit a fatal. Kept here for that pairing (decision
	 * 2026-09-20). Pro 4.3+ carries its own guarded copy in
	 * inc/Compat/legacy-functions.php; this one loads first (plugins_loaded 10)
	 * and wins, the add-on's stands down.
	 *
	 * REMOVE five releases after 4.2.2, once the Pro base has moved. Nothing in
	 * free may call it -- new code uses the aaeaddon_ name.
	 *
	 * @since 4.2.2
	 *
	 * @param array|null $args Optional `get_posts()` overrides.
	 * @return array<int,string>
	 */
	function wcf_addons_get_saved_template_list( $args = null ) {
		return aaeaddon_get_saved_template_list( $args );
	}
endif;

if ( ! function_exists( 'aaeaddon_validate_content_json' ) ) {
	function aaeaddon_validate_content_json( $input ) {
		// Check if the input is a valid string and not empty
		if ( ! is_string( $input ) || empty( $input ) ) {
			return false;  // Invalid input
		}

		// Attempt to decode the JSON
		$decoded = json_decode( $input, true );

		// Check for JSON decoding errors
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return false;  // Invalid JSON
		}

		// Return the decoded JSON if valid, otherwise false
		return $decoded;
	}
}

/**
 * Get database settings of a widget by widget id and element
 *
 * @param array $elements
 * @param string $widget_id
 *
 * @return false|mixed|string
 */
if ( ! function_exists( 'aaeaddon_get_widget_element_settings' ) ) :
	function aaeaddon_get_widget_element_settings( $elements, $widget_id ) {

		if ( is_array( $elements ) ) {
			foreach ( $elements as $d ) {
				if ( $d && ! empty( $d['id'] ) && $d['id'] == $widget_id ) {
					return $d;
				}
				if ( $d && ! empty( $d['elements'] ) && is_array( $d['elements'] ) ) {
					$value = aaeaddon_get_widget_element_settings( $d['elements'], $widget_id );
					if ( $value ) {
						return $value;
					}
				}
			}
		}

		return false;
	}
endif;

if ( ! function_exists( 'aaeaddon_get_widget_settings' ) ) {
	/**
	 * Get database settings of a widget by widget id and post id
	 *
	 * @param number $post_id Post ID.
	 * @param string $widget_id Widget ID.
	 *
	 * @return false|mixed|string
	 */
	function aaeaddon_get_widget_settings( $post_id, $widget_id ) {
		$document = \Elementor\Plugin::$instance->documents->get( $post_id );

		if ( $document ) {
			$elementor_data = $document->get_elements_data();
		}

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return array();
		}

		if ( empty( $elementor_data ) || ! is_array( $elementor_data ) ) {
			return array();
		}

		$element = aaeaddon_get_widget_element_settings( $elementor_data, $widget_id );

		return ! empty( $element['settings'] ) && is_array( $element['settings'] )
			? $element['settings']
			: array();
	}
}

/**
 * Get local plugin data
 *
 * @param string $basename
 *
 * @return false|mixed|string
 */
if ( ! function_exists( 'aaeaddon_get_local_plugin_data' ) ) :
	function aaeaddon_get_local_plugin_data( $basename = '' ) {
		if ( empty( $basename ) ) {
			return false;
		}

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins();

		if ( ! isset( $plugins[ $basename ] ) ) {
			return false;
		}

		return $plugins[ $basename ];
	}
endif;

/**
 * Get all widgets count
 *
 * @return numeric
 */
if ( ! function_exists( 'aaeaddon_get_all_widgets_count' ) ) :
	function aaeaddon_get_all_widgets_count() {

		$total  = 0;
		$config = aaeaddon_get_config();

		if ( empty( $config['widgets'] ) ) {
			return 0;
		}

		foreach ( $config['widgets'] as $group ) {
			if ( ! empty( $group['elements'] ) ) {
				$total += count( $group['elements'] );
			}
		}

		return $total;
	}
endif;

/**
 * Get active widgets count
 *
 * @return numeric
 */
if ( ! function_exists( 'aaeaddon_get_active_widgets_count' ) ) :
	function aaeaddon_get_active_widgets_count() {

		return get_option( 'aaeaddon_save_widgets' ) ? count( get_option( 'aaeaddon_save_widgets' ) ) : 0;
	}
endif;
/**
 * Get inactive widgets count
 *
 * @return numeric
 */
if ( ! function_exists( 'aaeaddon_get_inactive_widgets_count' ) ) :
	function aaeaddon_get_inactive_widgets_count() {
		return aaeaddon_get_all_widgets_count() - aaeaddon_get_active_widgets_count();
	}
endif;

/**
 * Get all Extensions count
 *
 * @return numeric
 */
if ( ! function_exists( 'aaeaddon_get_all_extensions_count' ) ) :
	function aaeaddon_get_all_extensions_count() {

		$total  = 0;
		$config = aaeaddon_get_config();

		if ( empty( $config['extensions'] ) ) {
			return 0;
		}

		foreach ( $config['extensions'] as $group ) {
			if ( ! empty( $group['elements'] ) ) {
				$total += count( $group['elements'] );
			}
		}

		return $total;
	}
endif;

/**
 * Check the element status
 *
 *  @return false|mixed|numeric
 */
if ( ! function_exists( 'aaeaddon_element_status' ) ) :
	function aaeaddon_element_status( $option_name, $key, $element = null ) {
		$status = checked( 1, aaeaddon_get_settings( $option_name, $key ), false );

		if ( ! is_null( $element ) ) {
			if ( $element['is_pro'] || $element['is_extension'] ) {

				// pro elements
				if ( $element['is_pro'] && ! aaeaddon_pro_defined( 'VERSION' ) ) {
					$status = 'disabled';
				}

				// extension elements
				if ( $element['is_extension'] && ! defined( 'WCF_ADDONS_EX_VERSION' ) ) {
					$status = 'disabled';
				}
			}
		}

		return $status;
	}
endif;

if ( ! function_exists( 'aaeaddon_get_settings' ) ) {

	/**
	 * Return saved settings.
	 *
	 * Renamed in 4.2.0 (the `aaeaddon_` prefix replaced the pre-4.2 family).
	 * The old spelling is a temporary shim right below -- the RELEASED add-on
	 * calls it unguarded on its boot path; see that shim's docblock.
	 *
	 * @since 4.2.0
	 *
	 * @param string      $option_name Option to read.
	 * @param string|null $element     Single key to return, or null for every truthy key.
	 * @return mixed
	 */
	function aaeaddon_get_settings( $option_name, $element = null ) {
		$elements = get_option( $option_name );
		return ( isset( $element ) ? ( isset( $elements[ $element ] ) ? $elements[ $element ] : 0 ) : array_keys( array_filter( $elements ) ) );
	}
}
if ( ! function_exists( 'wcf_addons_get_settings' ) ) {
	/**
	 * Pre-4.2 name of aaeaddon_get_settings() -- COMPATIBILITY SHIM.
	 *
	 * The RELEASED paid add-on (Pro <= 4.2.x) calls this name unguarded on 16
	 * lines, the first at include time (inc/live-event-handler.php:8), so a
	 * free without it takes every such site down on every request. Free 4.2.1
	 * shipped to WordPress.org on 2026-09-17 without it; kept here from 4.2.2
	 * (decision 2026-09-20). Pro 4.3+ carries its own guarded copy in
	 * inc/Compat/legacy-functions.php; this one loads first and wins.
	 *
	 * REMOVE five releases after 4.2.2, once the Pro base has moved. Nothing in
	 * free may call it -- new code uses the aaeaddon_ name.
	 *
	 * @since 4.2.2
	 *
	 * @param string      $option_name Option to read.
	 * @param string|null $element     Single key to return, or null for every truthy key.
	 * @return mixed
	 */
	function wcf_addons_get_settings( $option_name, $element = null ) {
		return aaeaddon_get_settings( $option_name, $element );
	}
}

if ( ! function_exists( 'aaeaddon_set_postview' ) ) {
	/**
	 * save single post view count
	 */
	function aaeaddon_set_postview() {

		// Avoid admin / ajax
		if ( is_admin() || wp_doing_ajax() ) {
			return;
		}

		// Only single posts (change if needed)
		if ( ! is_singular('post') ) {
			return;
		}

		// Pro counts the same key on the same `wp` hook (its counter also feeds
		// the trending score and skips logged-in / cookied repeat views). With
		// both running every uncached visit added 2 -- measured 3 -> 4 in one
		// request -- and paid three UPDATEs. One owner: Pro when it is there.
		if ( function_exists( 'aaeaddon_track_post_views_and_update_score' ) ) {
			return;
		}

		$post_id  = get_the_ID();
		$meta_key = 'wcf_post_views_count';

		$count = (int) get_post_meta($post_id, $meta_key, true);

		$count++;

		update_post_meta($post_id, $meta_key, $count);
	}
}

if ( ! function_exists( 'aaeaddon_get_nested_config_keys' ) ) {
	function aaeaddon_get_nested_config_keys( $array, &$foundKeys, &$active ) {
		foreach ( $array as $key => $value ) {
			// Check if the current key is one we're looking for
			if ( isset( $value['is_active'] ) && $value['is_active'] == true ) {
				// Add to found keys list
				$foundKeys[] = $key;
				// Store the entire element in $active
				$active[ $key ] = true;
			}

			// If value is an array, recurse into it
			if ( is_array( $value ) ) {
				aaeaddon_get_nested_config_keys( $value, $foundKeys, $active );
			}
		}
	}
}

if ( ! function_exists( 'aaeaddon_get_nested_active_config_keys' ) ) {
	function aaeaddon_get_nested_active_config_keys( $array, &$foundKeys, &$active ) {
		foreach ( $array as $key => $value ) {
			// Check if the current key is one we're looking for
			if ( isset( $value['is_upcoming'] ) && isset( $value['is_pro'] ) && isset( $value['is_active'] ) && $value['is_active'] == true ) {
				// Add to found keys list
				if ( isset( $value['is_upcoming'] ) && $value['is_upcoming'] !== true ) {
					$foundKeys[] = $key;
					// Store the entire element in $active
					$active[ $key ] = true;
				}
			}

			// If value is an array, recurse into it
			if ( is_array( $value ) ) {
				aaeaddon_get_nested_active_config_keys( $value, $foundKeys, $active );
			}
		}
	}
}

if ( ! function_exists( 'aaeaddon_get_db_updated_config' ) ) {

	function aaeaddon_get_db_updated_config( array &$configs, array $dbActiveElements ) {
		// Loop through each item in the configs array
		foreach ( $configs as $key => &$element ) {

			// Check if the current element is an array and has an 'is_active' field
			if ( is_array( $element ) && isset( $element['is_active'] ) ) {
				// If the current key is in the dbActiveElements array, update is_active to true
				if ( in_array( $key, $dbActiveElements ) ) {
					$element['is_active'] = true;
				}
			}

			// Recursively call the function for any nested elements
			if ( is_array( $element ) ) {
				aaeaddon_get_db_updated_config( $element, $dbActiveElements );
			}
		}
	}
}


if ( ! function_exists( 'aaeaddon_get_total_config_elements_by_key' ) ) {
	function aaeaddon_get_total_config_elements_by_key( $array, &$foundKeys = 0 ) {
		foreach ( $array as $key => $value ) {
			// Check if the current key is one we're looking for
			if ( isset( $value['is_active'] ) && isset( $value['is_extension'] ) && isset( $value['is_pro'] ) ) {
				++$foundKeys;
			}

			// If value is an array, recurse into it
			if ( is_array( $value ) ) {
				aaeaddon_get_total_config_elements_by_key( $value, $foundKeys );
			}
		}
	}
}


if ( ! function_exists( 'aaeaddon_get_search_active_keys' ) ) {
	function aaeaddon_get_search_active_keys( $array, $keysToFind, &$foundKeys, &$active ) {
		foreach ( $array as $key => $value ) {
			// Check if the current key is one we're looking for
			if ( in_array( $key, $keysToFind ) && is_array( $value ) && array_key_exists( 'is_extension', $value ) ) {
				// Add to found keys list
				$foundKeys[] = sanitize_text_field( $key );
				// Store the entire element in $active
				$value['is_active'] = 1;
				$active[ $key ]     = $value;
			}
			if ( is_array( $value ) ) {
				aaeaddon_get_search_active_keys( $value, $keysToFind, $foundKeys, $active );
			}
		}
	}
}

if ( ! function_exists( 'aaeaddon_config_index' ) ) {
	/**
	 * Flat `key => node` index of every activatable node in a config section.
	 *
	 * aaeaddon_get_search_active_keys() re-walks the whole ~2,125-node config tree on
	 * every call, and get_widgets()/get_extensions() are called several times per
	 * request (include_files() at plugins_loaded, the widget registrar, and Pro).
	 * Indexing once turns each of those from O(tree) into O(saved keys).
	 *
	 * Traversal order and last-wins-on-duplicate-keys match the recursive
	 * version exactly, and eligibility is the same `is_extension` test, so the
	 * resulting set is identical — only the cost changes.
	 *
	 * The recursive function is deliberately left in place: the admin screens
	 * (dashboard.php, setup-wizard.php) still use it, and they are not on a hot
	 * path.
	 *
	 * @param string $section 'widgets' or 'extensions'.
	 * @return array<string,array>
	 */
	function aaeaddon_config_index( $section ) {
		static $index = [];

		if ( isset( $index[ $section ] ) ) {
			return $index[ $section ];
		}

		$config = aaeaddon_get_config();
		$flat   = [];

		$walk = static function ( $nodes ) use ( &$walk, &$flat ) {
			foreach ( $nodes as $key => $value ) {
				if ( ! is_array( $value ) ) {
					continue;
				}
				if ( array_key_exists( 'is_extension', $value ) ) {
					$flat[ $key ] = $value;
				}
				// Keep descending even after a match — the original does, and a
				// deeper node with the same key is meant to win.
				$walk( $value );
			}
		};

		if ( ! empty( $config[ $section ] ) ) {
			$walk( $config[ $section ] );
		}

		$index[ $section ] = $flat;

		return $flat;
	}
}

if ( ! function_exists( 'aaeaddon_get_active_extension_by_key' ) ) {

	function aaeaddon_get_active_extension_by_key( $search ) {

		$ext = get_option( 'aaeaddon_save_extensions' );
		if ( is_array( $ext ) ) {
			$saved_ext = array_keys( $ext );
			$found_key = array_search( $search, $saved_ext );
			if ( $found_key !== false ) {
				return true;
			}
		} else {
			return true;
		}

		return false;
	}
}

if ( ! function_exists( 'aaeaddon_get_current_user_roles' ) ) {
	function aaeaddon_get_current_user_roles() {

		if ( is_user_logged_in() ) {

			$user = wp_get_current_user();

			$roles = (array) $user->roles;

			if ( is_super_admin() ) {
				$roles[] = 'administrator'; // Add administrator role for super admins
			}

			return $roles; // This will returns an array

		} else {

			return array();
		}
	}
}

if ( ! function_exists( 'aaeaddon_get_pronotice_html' ) ) {
	function aaeaddon_get_pronotice_html() {
		$img_src     = esc_url( AAEADDON_URL . 'assets/images/get-pro.png' ); // Replace '#' with the actual URL or dynamic value
		$upgrade_url = esc_url( 'https://animation-addons.com/' ); // Replace '#' with the actual upgrade URL

		return sprintf(
			'<div class="wcfaddon-pro-notice">
				<img src="%s" alt="%s" />
				<div class="wcfaddon-pro-notice-content">
					<h4>%s</h4>
					<p>%s</p>
					<a target="__blank" rel="nofollow" class="elementor-button elementor-button-default" href="%s">%s</a>
				</div>
			</div>',
			$img_src,
			esc_attr( __( 'Upgrade Notice', 'animation-addons-for-elementor' ) ),
			__( 'Upgrade to premium plan and unlock every feature!', 'animation-addons-for-elementor' ),
			__( 'Upgrade and get access to every feature.', 'animation-addons-for-elementor' ),
			$upgrade_url,
			__( 'Upgrade Animation Addon', 'animation-addons-for-elementor' )
		);
	}
}

if ( ! function_exists( 'aaeaddon_format_number_count' ) ) {
	function aaeaddon_format_number_count( $count ) {
		if ( $count >= 1000000000 ) {
			return number_format( $count / 1000000000, 1 ) . esc_html__( 'b', 'animation-addons-for-elementor' ); // Billion
		} elseif ( $count >= 1000000 ) {
			return number_format( $count / 1000000, 1 ) . esc_html__( 'm', 'animation-addons-for-elementor' ); // Million
		} elseif ( $count >= 1000 ) {
			return number_format( $count / 1000, 1 ) . esc_html__( 'k', 'animation-addons-for-elementor' ); // Thousand
		}
		return $count; // Less than 1000, return the count as is
	}
}

if ( ! function_exists( 'aaeaddon_filter_search_by_date_and_category' ) ) :
// Search Filtering
function aaeaddon_filter_search_by_date_and_category( $query ) {
	if ( is_admin() || wp_doing_ajax() ) return; // added v-2.6.0
 	if ( ! $query->is_search() || ! $query->is_main_query() ) return; // added v-2.6.0

	if ( $query->is_search() && $query->is_main_query() && ! is_admin() ) {

		// ==== Date range filter ====
		// Read-only public search query parameters; no nonce applies to a GET search form.
		$from_date = isset( $_GET['from_date'] ) ? sanitize_text_field( wp_unslash( $_GET['from_date'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$to_date   = isset( $_GET['to_date'] ) ? sanitize_text_field( wp_unslash( $_GET['to_date'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( $from_date || $to_date ) {
			$date_query = array( 'inclusive' => true );
			if ( $from_date ) {
				$date_query['after'] = $from_date;
			}
			if ( $to_date ) {
				$date_query['before'] = $to_date;
			}
			$query->set( 'date_query', array( $date_query ) );
		}

		// ==== Category filter ====
		// Read-only public search query parameters; no nonce applies to a GET search form.
		if ( isset( $_GET['category'] ) && is_array( $_GET['category'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$categories = array_filter( array_map( 'intval', wp_unslash( $_GET['category'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			if ( ! empty( $categories ) ) {
				$query->set( 'category__in', $categories );
			}
		}
	}
}
endif;

add_action( 'pre_get_posts', 'aaeaddon_filter_search_by_date_and_category' );

if ( ! function_exists( 'aaeaddon_breadcrumbs' ) ) {
	/**
	 * AAE Breadcrumbs.
	 *
	 * @param string $html_tag HTML tag to use for the breadcrumbs' container.
	 * @param string $separator Separator to use between breadcrumbs.
	 *
	 * @return void
	 */
	function aaeaddon_breadcrumbs( $html_tag = 'div', $separator = ' &raquo; ' ) {
		global $post;

		$breadcrumbs   = array();
		$home_url      = get_home_url();
		$breadcrumbs[] = '<a href="' . esc_url( $home_url ) . '">' . esc_html__( 'Home', 'animation-addons-for-elementor' ) . '</a>';

		if ( is_front_page() ) {
			echo '<' . esc_attr( $html_tag ) . ' class="aae-breadcrumbs">';
			echo wp_kses_post( implode( $separator, $breadcrumbs ) );
			echo '</' . esc_attr( $html_tag ) . '>';
			return;
		}

		if ( is_category() || ( is_single() && get_post_type() === 'post' ) ) {
			if ( is_category() ) {
				$category = get_queried_object();

				if ( $category && ! is_wp_error( $category ) ) {
					if ( $category->parent ) {
						$category_parents = array();
						$current_cat      = $category;

						while ( $current_cat->parent ) {
							$current_cat = get_category( $current_cat->parent );
							if ( $current_cat && ! is_wp_error( $current_cat ) ) {
								$category_parents[] = '<a href="' . esc_url( get_category_link( $current_cat->term_id ) ) . '">' . esc_html( $current_cat->name ) . '</a>';
							}
						}

						$breadcrumbs = array_merge( $breadcrumbs, array_reverse( $category_parents ) );
					}

					$breadcrumbs[] = esc_html( $category->name );
				}
			} elseif ( is_single() && get_post_type() === 'post' ) {
				$cat = get_the_category();
				if ( ! empty( $cat ) ) {
					$category = $cat[0];

					if ( $category->parent ) {
						$category_parents = array();
						$current_cat      = $category;

						while ( $current_cat->parent ) {
							$current_cat = get_category( $current_cat->parent );
							if ( $current_cat && ! is_wp_error( $current_cat ) ) {
								$category_parents[] = '<a href="' . esc_url( get_category_link( $current_cat->term_id ) ) . '">' . esc_html( $current_cat->name ) . '</a>';
							}
						}

						$breadcrumbs = array_merge( $breadcrumbs, array_reverse( $category_parents ) );
					}

					$breadcrumbs[] = '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a>';

					$breadcrumbs[] = esc_html( get_the_title() );
				}
			}
		} elseif ( is_page() ) {
			if ( $post->post_parent ) {
				$parent_id     = $post->post_parent;
				$parent_crumbs = array();

				while ( $parent_id ) {
					$page = get_post( $parent_id );
					if ( $page ) {
						$parent_crumbs[] = '<a href="' . esc_url( get_permalink( $page->ID ) ) . '">' . esc_html( get_the_title( $page->ID ) ) . '</a>';
						$parent_id       = $page->post_parent;
					} else {
						break;
					}
				}

				$breadcrumbs = array_merge( $breadcrumbs, array_reverse( $parent_crumbs ) );
			}

			$breadcrumbs[] = esc_html( get_the_title() );
		} elseif ( is_singular() && ! is_page() ) {
			$post_type = get_post_type_object( get_post_type() );

			if ( $post_type && $post_type->has_archive ) {
				$breadcrumbs[] = '<a href="' . esc_url( get_post_type_archive_link( get_post_type() ) ) . '">' . esc_html( $post_type->labels->name ) . '</a>';
			}

			$taxonomies = get_object_taxonomies( get_post_type() );
			foreach ( $taxonomies as $taxonomy ) {
				$terms = get_the_terms( get_the_ID(), $taxonomy );
				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
					$term = current( $terms );

					if ( $term->parent ) {
						$term_parents = array();
						$current_term = $term;

						while ( $current_term->parent ) {
							$current_term = get_term( $current_term->parent, $taxonomy );
							if ( $current_term && ! is_wp_error( $current_term ) ) {
								$term_parents[] = '<a href="' . esc_url( get_term_link( $current_term ) ) . '">' . esc_html( $current_term->name ) . '</a>';
							}
						}

						$breadcrumbs = array_merge( $breadcrumbs, array_reverse( $term_parents ) );
					}

					$breadcrumbs[] = '<a href="' . esc_url( get_term_link( $term ) ) . '">' . esc_html( $term->name ) . '</a>';
					break;
				}
			}

			$breadcrumbs[] = esc_html( get_the_title() );
		} elseif ( is_archive() ) {
			if ( is_post_type_archive() ) {
				$breadcrumbs[] = esc_html( post_type_archive_title( '', false ) );
			} elseif ( is_tax() || is_tag() ) {
				$term = get_queried_object();

				if ( isset( $term->parent ) && $term->parent ) {
					$term_parents = array();
					$current_term = $term;

					while ( $current_term->parent ) {
						$current_term = get_term( $current_term->parent, $term->taxonomy );
						if ( $current_term && ! is_wp_error( $current_term ) ) {
							$term_parents[] = '<a href="' . esc_url( get_term_link( $current_term ) ) . '">' . esc_html( $current_term->name ) . '</a>';
						}
					}

					$breadcrumbs = array_merge( $breadcrumbs, array_reverse( $term_parents ) );
				}

				$breadcrumbs[] = esc_html( $term->name );
			} elseif ( is_day() ) {
				$breadcrumbs[] = esc_html( get_the_date( 'F j, Y' ) );
			} elseif ( is_month() ) {
				$breadcrumbs[] = esc_html( get_the_date( 'F Y' ) );
			} elseif ( is_year() ) {
				$breadcrumbs[] = esc_html( get_the_date( 'Y' ) );
			} elseif ( is_author() ) {
				$breadcrumbs[] = esc_html__( 'Author: ', 'animation-addons-for-elementor' ) . esc_html( get_the_author() );
			} else {
				$breadcrumbs[] = esc_html__( 'Archives', 'animation-addons-for-elementor' );
			}
		} elseif ( is_search() ) {
			$breadcrumbs[] = esc_html__( 'Search Results for: ', 'animation-addons-for-elementor' ) . esc_html( get_search_query() );
		} elseif ( is_404() ) {
			$breadcrumbs[] = esc_html__( '404 - Page not found', 'animation-addons-for-elementor' );
		}

		echo '<' . esc_attr( $html_tag ) . ' class="aae-breadcrumbs">';
		echo wp_kses_post( implode( $separator, $breadcrumbs ) );
		echo '</' . esc_attr( $html_tag ) . '>';
	}
}

/**
 * Add AAE Loop to Elementor Edit Page
 *
 * @since 2.4.5
 * @return void
 */
add_filter(
	'elementor/frontend/admin_bar/settings',
	function ( $settings ) {
		foreach ( $settings['elementor_edit_page']['children'] as $id => $item ) {
			$post_type = get_post_type( $id );

			if ( 'wcf-addons-template' === $post_type ) {
				switch ( get_post_meta( $id, 'wcf-addons-template-meta_type', true ) ) {
					case 'loop-builder':
						$settings['elementor_edit_page']['children'][ $id ]['sub_title'] = 'AAE Loop';
						break;
					case 'footer':
						$settings['elementor_edit_page']['children'][ $id ]['sub_title'] = 'AAE Footer';
						break;
					case 'header':
						$settings['elementor_edit_page']['children'][ $id ]['sub_title'] = 'AAE Header';
						break;
					case 'popup':
						$settings['elementor_edit_page']['children'][ $id ]['sub_title'] = 'AAE Pop-Up';
						break;
					case 'single':
						$settings['elementor_edit_page']['children'][ $id ]['sub_title'] = 'AAE Single';
						break;
					case 'archive':
						$settings['elementor_edit_page']['children'][ $id ]['sub_title'] = 'AAE archive';
						break;
				}
			}
		}
		return $settings;
	}
);


if ( ! function_exists( 'aaeaddon_get_config' ) ) :
/**
 * The widget/extension config tree from config.php.
 *
 * A `static` rather than the object cache, for two reasons:
 *
 * 1. SPEED. config.php is ~128 KB / 3,553 lines. Without a persistent object
 *    cache backend wp_cache_get() is request-scoped anyway, so the round trip
 *    bought nothing while still costing a cache lookup on every call.
 * 2. CORRECTNESS on sites that DO have Redis/Memcached. The old code cached a
 *    serialized copy of the file's contents under a key with no version in it,
 *    so a plugin update could keep serving the PREVIOUS release's config until
 *    the cache was flushed by hand. A static cannot outlive the request, so it
 *    can never be stale.
 */
function aaeaddon_get_config() {

    static $config = null;

    if (null === $config) {
        $config = require AAEADDON_PATH . 'config.php';
    }

    return $config;

}
endif;



if ( ! function_exists( 'aaeaddon_asset_version' ) ) :
/**
 * Version string for this plugin's own admin assets.
 *
 * DEV: a timestamp, so an edited bundle is picked up without a hard refresh.
 * PRODUCTION: the plugin version, so the browser can actually cache the file.
 *
 * Seven enqueues used to pass a bare `time()` with no condition at all, which
 * meant every visitor to the dashboard, the importer or the plugins screen
 * re-downloaded the bundle on EVERY page load — the dashboard's is ~620 KB of
 * JS plus its CSS — and no `Cache-Control` could ever help, because the URL
 * changed each second. It defeated browser and CDN caching alike, on live
 * sites, permanently.
 *
 * Dev is decided by `Atomic::is_dev_environment()` — SCRIPT_DEBUG, a
 * localhost/127.0.0.1 host, a `.local`/`.test` domain, or a loopback SERVER_ADDR
 * — reusing the existing rule rather than inventing a second one that could
 * disagree with it. Deliberately NOT WP_DEBUG: that is about error reporting,
 * and plenty of live sites run with it on.
 *
 * The timestamp is resolved ONCE per request, so every asset on a page shares
 * one version rather than straddling a second boundary.
 *
 * @return string
 */
function aaeaddon_asset_version() {
	static $version = null;

	if ( null !== $version ) {
		return $version;
	}

	$is_dev = false;

	// Guarded: the atomic registry is a separate subsystem and this helper is
	// loaded on every request, including ones where that class may not be.
	if ( class_exists( '\Wealcoder\AnimationAddons\AtomicWidgets\Atomic' ) ) {
		$atomic = \Wealcoder\AnimationAddons\AtomicWidgets\Atomic::instance();

		if ( method_exists( $atomic, 'is_dev_environment_public' ) ) {
			$is_dev = $atomic->is_dev_environment_public();
		}
	}

	$version = $is_dev ? (string) time() : AAEADDON_VERSION;

	return $version;
}
endif;

if ( ! function_exists( 'aaeaddon_kses_builder_html' ) ) {
	/**
	 * Escape markup another renderer produced -- an Elementor template, a
	 * theme-builder document, a Loop Item, a post's the_content -- for output.
	 *
	 * It is wp_kses() with the allow-list a page builder's output needs (SVG,
	 * iframe, form, media), <style> blocks carried beside kses with their
	 * CSS tag-stripped, <script> blocks removed with their contents. A plain
	 * function rather than the static method it wraps because that is what an
	 * escaping-function list can name. The whole of it: \Wealcoder\AnimationAddons\Kses.
	 *
	 * @param string $html Rendered markup.
	 * @return string
	 */
	function aaeaddon_kses_builder_html( $html ) {
		return \Wealcoder\AnimationAddons\Kses::builder_html( $html );
	}
}

if ( ! function_exists( 'aaeaddon_print_builder_html' ) ) {
	/**
	 * Print markup another renderer produced -- the `echo` form of
	 * aaeaddon_kses_builder_html(), with the same allow-list and the same
	 * result on the page. Every piece goes out through core: the markup by
	 * `echo wp_kses()`, a <style> block by WP_Styles' inline printer, a data
	 * <script> by wp_print_inline_script_tag(). See Kses::print_builder_html().
	 *
	 * @param string $html Rendered markup.
	 * @return void
	 */
	function aaeaddon_print_builder_html( $html ) {
		\Wealcoder\AnimationAddons\Kses::print_builder_html( $html );
	}
}

if ( ! function_exists( 'aaeaddon_print_css' ) ) {
	/**
	 * Print CSS inside a <style> element through WP_Styles' own inline
	 * printer: tag-stripped, registered on a src-less handle, printed by
	 * core. Works in the head, the body, the footer and an admin-ajax
	 * response alike. The element's id is `aae-css-<id>-inline-css`.
	 *
	 * @param string       $css   CSS text.
	 * @param string|array $attrs Handle suffix, or an attribute map (`id`, `media`).
	 * @return void
	 */
	function aaeaddon_print_css( $css, $attrs = '' ) {
		\Wealcoder\AnimationAddons\Kses::print_css( $css, $attrs );
	}
}

if ( ! function_exists( 'aaeaddon_key_map' ) ) {
	/**
	 * The key map: every persisted name this plugin and the paid add-on own,
	 * old spelling => `aaeaddon_` spelling. See inc/Compat/key-map.php.
	 *
	 * @return array
	 */
	function aaeaddon_key_map() {
		return \Wealcoder\AnimationAddons\Compat\Key_Bridge::map();
	}
}

if ( ! function_exists( 'aaeaddon_option_name' ) ) {
	/**
	 * The spelling a bridged option is LIVE under right now — for a caller that
	 * must address the row without going through get_option() (a $wpdb query,
	 * wp_load_alloptions()). Everything else just uses the new name.
	 *
	 * @param string $name Either spelling.
	 * @return string
	 */
	function aaeaddon_option_name( $name ) {
		return \Wealcoder\AnimationAddons\Compat\Key_Bridge::live_name( $name );
	}
}

if ( ! function_exists( 'aaeaddon_delete_option' ) ) {
	/**
	 * delete_option() for a bridged name: removes BOTH spellings, so "the option
	 * is gone" stays true whichever name a reader uses. A bare delete_option()
	 * on the non-live spelling finds no row and silently does nothing.
	 *
	 * @param string $name Either spelling.
	 * @return bool
	 */
	function aaeaddon_delete_option( $name ) {
		return \Wealcoder\AnimationAddons\Compat\Key_Bridge::delete_option( $name );
	}
}
