<?php

namespace Wealcoder\AnimationAddons\Atomic\Sticky;

use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Wealcoder\AnimationAddons\Atomic\PropTypes\Responsive_JSON_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Schema {

	const STICKY_SECTION_ANCHOR      = 'aae_sticky_section_anchor';

	const STICKY_ENABLE              = 'aae_sticky_enable';

	const STICKY_PIN_TRIGGER         = 'aae_sticky_pin_trigger';
	const STICKY_CUSTOM_PIN_AREA     = 'aae_sticky_custom_pin_area';

	const STICKY_PIN_END_TRIGGER     = 'aae_sticky_pin_end_trigger';
	const STICKY_CUSTOM_PIN_END_AREA = 'aae_sticky_custom_pin_end_area';

	const STICKY_PIN                 = 'aae_sticky_pin';
	const STICKY_CUSTOM_PIN          = 'aae_sticky_custom_pin';

	const STICKY_PIN_START           = 'aae_sticky_pin_start';

	const STICKY_PIN_END             = 'aae_sticky_pin_end';

	const STICKY_PIN_SPACING         = 'aae_sticky_pin_spacing';

	const STICKY_PIN_MARKERS         = 'aae_sticky_pin_markers';

	const STICKY_BORDER              = 'aae_sticky_border';

	const STICKY_TOGGLE_CLASS        = 'aae_sticky_toggle_class';
	const STICKY_BG_COLOR            = 'aae_sticky_bg_color';

	const STICKY_ENABLE_EDITOR       = 'aae_sticky_enable_editor';

	public function register(): void {

		add_filter(
			'elementor/atomic-widgets/props-schema',
			[ $this, 'add_sticky_props' ]
		);
	}

	public function add_sticky_props( array $schema ): array {

		if ( ! class_exists( Boolean_Prop_Type::class ) ) {
			return $schema;
		}

		/*
		|--------------------------------------------------------------------------
		| Anchor
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_SECTION_ANCHOR ] =
			Section_Anchor_Prop_Type::make()->default( '' );

		/*
		|--------------------------------------------------------------------------
		| Enable
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_ENABLE ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => false,
				]);

		/*
		|--------------------------------------------------------------------------
		| Sticky Enabled Dependency
		|--------------------------------------------------------------------------
		*/

		$sticky_enabled_dependency = Dependency_Manager::make()
			->where([
				'operator' => 'eq',
				'path'     => [ self::STICKY_ENABLE ],
				'value'    => false,
				'effect'   => 'hide',
			])
			->get();

		/*
		|--------------------------------------------------------------------------
		| Pin Trigger
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_PIN_TRIGGER ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => 'default',
				])
				->set_dependencies( $sticky_enabled_dependency );

		$schema[ self::STICKY_CUSTOM_PIN_AREA ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => '',
				]);

		/*
		|--------------------------------------------------------------------------
		| Pin End Trigger
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_PIN_END_TRIGGER ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => 'default',
				])
				->set_dependencies( $sticky_enabled_dependency );

		$schema[ self::STICKY_CUSTOM_PIN_END_AREA ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => '',
				]);

		/*
		|--------------------------------------------------------------------------
		| Pin
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_PIN ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => true,
				])
				->set_dependencies( $sticky_enabled_dependency );

		$schema[ self::STICKY_CUSTOM_PIN ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => '',
				]);

		/*
		|--------------------------------------------------------------------------
		| Pin Start
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_PIN_START ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => 'top top',
				])
				->set_dependencies( $sticky_enabled_dependency );

		/*
		|--------------------------------------------------------------------------
		| Pin End
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_PIN_END ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => 'bottom bottom',
				])
				->set_dependencies( $sticky_enabled_dependency );

		/*
		|--------------------------------------------------------------------------
		| Pin Spacing
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_PIN_SPACING ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => true,
				])
				->set_dependencies( $sticky_enabled_dependency );

		/*
		|--------------------------------------------------------------------------
		| Pin Markers
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_PIN_MARKERS ] =
			Boolean_Prop_Type::make()
				->default( false )
				->set_dependencies( $sticky_enabled_dependency );

		/*
		|--------------------------------------------------------------------------
		| Toggle Class
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_TOGGLE_CLASS ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => '',
				])
				->set_dependencies( $sticky_enabled_dependency );

		/*
		|--------------------------------------------------------------------------
		| Background Color
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_BG_COLOR ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => '',
				])
				->set_dependencies( $sticky_enabled_dependency );

		/*
		|--------------------------------------------------------------------------
		| Border
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_BORDER ] =
			Responsive_JSON_Prop_Type::make()
				->default([
					'desktop' => [
						'style'  => '',
						'width'  => [
							'top'    => '',
							'right'  => '',
							'bottom' => '',
							'left'   => '',
						],
						'color'  => '',
						'radius' => '',
					],
				])
				->set_dependencies( $sticky_enabled_dependency );

		/*
		|--------------------------------------------------------------------------
		| Enable Editor
		|--------------------------------------------------------------------------
		*/

		$schema[ self::STICKY_ENABLE_EDITOR ] =
			Boolean_Prop_Type::make()
				->default( false )
				->set_dependencies( $sticky_enabled_dependency );

		return $schema;
	}

	/**
	 * Container types only — pinning a heading pins nothing a user can see.
	 *
	 * "Container" here means Atomic_Element_Base (an element that holds
	 * children), not Bootstrap::target_element_types(), which is every
	 * animatable atomic widget. Everything below satisfies that test:
	 * Elementor core's three layout elements and its whole Tabs family, plus
	 * the two AAE panel children, which are `e-con`-based and are exactly the
	 * rows a user wants to pin one of while the rest scroll past.
	 */
	public static function targeted_elements(): array {
		return [
			'e-flexbox',
			'e-div-block',
			'e-grid',

			// Elementor core Tabs family.
			'e-tabs',
			'e-tabs-menu',
			'e-tab',
			'e-tabs-content-area',
			'e-tab-content',

			// AAE composite panel children.
			'e-aae-a-accordion-item',
			'e-aae-a-toggle-pane',
		];
	}
}