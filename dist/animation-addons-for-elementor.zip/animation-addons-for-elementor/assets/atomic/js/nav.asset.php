<?php return array('dependencies' => array(), 'version' => 'bbd0db8f678405b682f5');
